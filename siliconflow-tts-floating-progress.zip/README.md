# SiliconFlow TTS for SillyTavern - floating progress bar build

这是一个用于 SillyTavern 的硅基流动语音扩展修改版。

本项目基于 [hjl2004-10/extension](https://github.com/hjl2004-10/extension) 修改，感谢原作者的项目基础。本仓库保留原项目出处，并在原功能基础上调整了悬浮语音进度条在 PC、小窗口、平板和手机上的显示方式。

## 修改内容

- 自动朗读角色消息默认开启；自动朗读用户消息默认关闭，可在扩展设置里切换。
- 每条消息名字旁边有手动朗读按钮，可以单独朗读该条消息。
- 同一段文本会缓存音频，再次播放时复用缓存，不重复请求 API。
- 将悬浮语音进度条从浏览器原生 `audio controls` 改为自绘悬浮栏。
- 开关打开时，进度条立即显示，不依赖是否正在播放语音。
- 开关关闭时，进度条立即隐藏。
- 默认位置改为左下角，左边留 20px，减少小窗口、平板、手机上被遮挡的问题。
- 悬浮栏支持拖动，并提供“重置位置”。
- 三点菜单包含：
  - TTS 日志
  - 下载音频
  - 重置位置
  - 播放速度：0.75x / 1x / 1.25x / 1.5x / 2x
- 悬浮栏版本标记为 `v1.6.1`，用于确认浏览器是否加载到新版文件。

## 自动播放说明

插件有自动朗读功能，但最终是否能立刻出声会受浏览器限制影响：

- 角色消息：默认自动合成并尝试播放。
- 用户消息：默认不自动朗读，需要手动打开。
- PC 端通常可以直接播放。
- 手机浏览器可能会拦截自动播放。如果生成了音频但没出声，先点页面一次，或点悬浮进度条上的 `▶` 播放。
- 部分手机端需要长按/拉拽“下载音频”后，系统才会刷新出语音进度条；平板可能要等缓存读取完，再点 `▶` 播放。
- 点击消息旁边的 `▶` 可以手动朗读单条消息，也会复用已生成的缓存音频。

## 安装

推荐在 SillyTavern 的扩展页面用仓库地址安装：

```text
https://github.com/lynn33-2728/sillytavern-siliconflow-tts
```

也可以手动把本仓库放到 SillyTavern 的第三方扩展目录：

```text
SillyTavern/data/default-user/extensions/sillytavern-siliconflow-tts
```

然后刷新 SillyTavern 页面，在扩展设置里配置 SiliconFlow API。

`index.js` 会按实际安装文件夹自动加载同目录下的 `example.html` 作为设置面板。

## 出处与许可

本项目是 [hjl2004-10/extension](https://github.com/hjl2004-10/extension) 的修改版。

原项目版权归原作者所有。修改部分由本仓库维护者添加。项目按 MIT License 发布，详见 [LICENSE](LICENSE)。
